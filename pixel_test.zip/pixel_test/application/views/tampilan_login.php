
<!DOCTYPE html>
<html>

<head>

  <meta charset="UTF-8">

  <title>Twitter Aplication</title>

    <link rel="stylesheet" href="<? echo base_url(); ?>assets/css/style.css" media="screen" type="text/css" />

    <link rel="stylesheet" href="<? echo base_url(); ?>assets/css/bootstrap.css" media="screen" type="text/css" />

  <script src='<? echo base_url(); ?>assets/js/bootstrap.js'></script>

  <script src='<? echo base_url(); ?>assets/js/jquery.js'></script>

  <script src="<? echo base_url(); ?>assets/index.js"></script>
<script type="text/javascript">

$(document).ready(function(){


//alert('x');

$('#email').focus();

$('#email').keypress(function(event){
	if (event.which == 13) {
		var e = jQuery.Event('keypress');
		e.which = 13;
		$('#loginx').click();
	}
});	

$('#pass').keypress(function(event){
	if (event.which == 13) {
		var e = jQuery.Event('keypress');
		e.which = 13;
		
		$('#loginx').click();
	}
});	
$('#email_reg').keypress(function(event){
	if (event.which == 13) {
		var e = jQuery.Event('keypress');
		e.which = 13;
		$('#register').click();
	}
});	

$('#pass_reg').keypress(function(event){
	if (event.which == 13) {
		var e = jQuery.Event('keypress');
		e.which = 13;
		
		$('#register').click();
	}
});	
$('#nama_reg').keypress(function(event){
	if (event.which == 13) {
		var e = jQuery.Event('keypress');
		e.which = 13;
		
		$('#register').click();
	}
});	




	$('#loginx').click(function(){

		var email1 = $('#email').val();
		var pass1 = $('#pass').val();

	if(pass1=="" || email1==""){
			$('#infox').html("<div class=\"alert alert-warning\" role=\"alert\">"+
				"<h3>Data tidak lengkap!</h3>harap melengkapi form yang disediakan"+
				"</div>");
			return;
		}
		


jQuery.ajax({
			type	: 'POST',
			url 	: '<? echo site_url(); ?>/login/getlogin',
			data 	: {email:email1,pass:pass1},
			success: function(data){
			//	alert(data);
				
var res = data.trim();
				if(res=="OK"){
				$('#infox').html("<div class=\"alert alert-success\" role=\"alert\">"+
				"<h3>Terima kasih!</h3>Mengarahkan anda ke halaman aplikasi"+
				"</div>");
			
				window.location="<? echo site_url(); ?>/home";
			} else {
				$('#infox').html("<div class=\"alert alert-danger\" role=\"alert\">"+
				"<h3>"+data+"</h3>"+
				data+
				"</div>");
				
				return;
				
			}

			}

		});


	});



	$('#register').click(function(){

		var email1 = $('#email_reg').val();
		var nama1 = $('#name_reg').val();
		var pass1 = $('#pass_reg').val();
	if(pass1=="" || email1=="" || pass1){
			$('#info').html("<div class=\"alert alert-warning\" role=\"alert\">"+
				"<h3>Data tidak lengkap!</h3>harap melengkapi form yang disediakan"+
				"</div>");
			return;
		}
		

	

jQuery.ajax({
			type	: 'POST',
			url 	: '<? echo site_url(); ?>/register/simpan',
			data 	: {email:email1,pass:pass1,nama:nama1},
			success: function(data){
				//	alert(data);
					var res = data.trim();
				if(res=="OK"){
				$('#info').html("<div class=\"alert alert-success\" role=\"alert\">"+
				"<h3>Terima kasih!</h3>Anda Berhasil Registrasi"+
				"</div>");
					 $('#email_reg').val('');
					 $('#name_reg').val('');
					 $('#pass_reg').val('');
					$('#email_reg').focus();

			} else {
				$('#info').html("<div class=\"alert alert-danger\" role=\"alert\">"+
				"<h3>"+data+"</h3>"+
				data+
				"</div>");
				
				return;
				
			}

			}

		});
});


});
</script>
		





</head>

<body>

 
<div id="login">

  <h1>Twitter Aplication</h1>
  <form>
  	<h4>LOGIN</h4>
    <div id="infox"></div>
    <input type="email" id="email" placeholder="Email" />
    <input type="password" id="pass" placeholder="Password" />
    <input type="button" id="loginx" class="btn btn-primary"  value="Login" />
  

  </form>

   <form>
   	<div id="info"></div>
 
  	<h4>REGISTER</h4>
    <input type="email" id="email_reg" placeholder="Email" />
    <input type="nama" id="name_reg" placeholder="Name" />
    <input type="password" id="pass_reg" placeholder="Password" />
    <input type="button" id="register" class="btn btn-primary" value="Register" />
  

  </form>


</div>


</body>

</html>