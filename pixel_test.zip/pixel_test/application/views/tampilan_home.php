
<!DOCTYPE html>
<html>

<head>

  <meta charset="UTF-8">

  <title>Twitter Aplication</title>

    <link rel="stylesheet" href="<? echo base_url(); ?>assets/css/style_home.css" media="screen" type="text/css" />

    <link rel="stylesheet" href="<? echo base_url(); ?>assets/css/bootstrap.css" media="screen" type="text/css" />

  <script src='<? echo base_url(); ?>assets/js/bootstrap.js'></script>

  <script src='<? echo base_url(); ?>assets/js/jquery.js'></script>

  <script src="<? echo base_url(); ?>assets/index.js"></script>
<script type="text/javascript">

$(document).ready(function(){



$('#status').val('');

$('#status').focus();
 
$('#status').keypress(function(event){
  if (event.which == 13) {
    var e = jQuery.Event('keypress');
    e.which = 13;
    //alert('1');
    $('#update_status').click();
  


  }
}); 



  $('#update_status').click(function(){
    //alert('2');
    var status1 = $('#status').val();

    var email1 = $('#email').val();
    var nama1 = $('#nama').val();

      if(status1==""){
      $('#info').html("<div class=\"alert alert-warning\" role=\"alert\">"+
        "<h3>Ups!</h3>Status Masih Kosong"+
        "</div>");
     // alert('3')
      return;
    }
//var email1 = <? //echo $mail; ?>;

//alert(status1+'--'+email1+'--'+nama1);
    //alert('<? //echo site_url(); ?>/home/simpan');
  
jQuery.ajax({
      type  : 'POST',
      url   : '<? echo site_url(); ?>/home/simpan',
      data  : {status:status1,email:email1,nama:nama1 },
      success: function(data){
        alert('Update Berhasil');
        
        $("#tampil").html(data);

      }

    });
});


});
</script>
    

</head>

<div id="tampil">
<body>
<div id="info"></div>
 
<div id="status_input">

  <h1>Twitter Aplication</h1>
  <form id="input">
  	<? //echo"Hi,". $uname ."($mail)"; ?>
    <input type="hidden" value="<? echo $mail; ?>" id="email">
    <input type="hidden" value="<? echo $uname; ?>" id="nama">
    <a href="<? echo site_url();?>/profile">Setting Profile </a> | 
  	<a href="<? echo site_url();?>/home/logout">Logout </a>
    <input type="status" id="status" placeholder="Update status..." />
    <input type="button" id="update_status" class="btn btn-primary"  value="update status" />
  

  </form>

  <form id="tampil">
    
    <? echo"Hi,". $uname ; ?>
<div >
<?  foreach( $data->result() as $row ){ 
$mmail = $row->email ;
?>
<table  class="status_view">
<tr>
<td class="nav ace-nav">
 
<?


if($mmail == $mail){
?>
<table>
 <tr>
    <td width="80%">
  <? echo $row->isi_status."(". $row->tgl_status .")" ; ?>
</td>
<td width="20%">
<a href="">
<? 
if(!empty($row->foto)){

echo'<img class="nav-user-photo-my"  src="data:image/jpeg;base64,' . base64_encode($row->foto) . ' " >'; 
}else{

?>

<img class="nav-user-photo-my" src="<? echo base_url();?>assets/img/user.gif" >

<? } ?>
</a>
</td></tr>
</table>


<?
}else{
  ?>
 <table>
 <tr>
    <td width="20%"> 
<a href="">
<? 
if(!empty($row->foto)){

echo'<img class="nav-user-photo"  src="data:image/jpeg;base64,' . base64_encode($row->foto) . ' " >'; 

}else{

?>

<img class="nav-user-photo" src="<? echo base_url();?>assets/img/user.gif" >

<? } ?>
</a>
</td>
<td width="80%" align="right">
 <? echo $row->isi_status."(". $row->tgl_status .")" ; ?>
 </td></tr>
</table>
<?
}

  ?>

</td>	
</tr>
</table>
<? } ?>
</div>
 


  </form>



</div>


</body>
</div>
</html>