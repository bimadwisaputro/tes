
	

		<!-- inline scripts related to this page -->
		<script type="text/javascript">
		function menu(x,y,z,q) {

	if (typeof (history.pushState) != "undefined") {
        var obj = { Title: "test", Url: "paket" };
        history.pushState(obj, obj.Title, obj.Url);
    }

			//alert(x);

		$.ajax({
			type	: 'POST',
			url 	: '<? echo site_url(); ?>/'+x+'/'+q+'',
			data 	: {judul:y,sub_judul:z},
			success: function(data){
			$('#tampilcontent').html(data);
			}

		});



}





		</script>

				<ul class="nav nav-list">
					<li class="active">
						<a href="<? echo base_url();?>index.php/home">
							<i class="menu-icon fa fa-tachometer"></i>
							<span class="menu-text"> Dashboard </span>
						</a>

						<b class="arrow"></b>
					</li>

					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-desktop"></i>
							<span class="menu-text">
								Master  
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="javascript:;" onclick="menu('karyawan','tampilconten');">
									<i class="menu-icon fa fa-caret-right"></i>

									Karyawan
								</a>
								
							</li>

							

							<li class="">
								<a  class="ajax-link" href="ajax/tables_simple.html">
									<i class="menu-icon fa fa-caret-right"></i>
									Jenis Mainan
								</a>

								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="javascript:;" onclick="menu('paket','Master', 'Paket','tampilconten');">
									<i class="menu-icon fa fa-caret-right"></i>
									Item Mainan
								</a>

								<b class="arrow"></b>
							</li>
							<li class="">
								<a href="javascript:;" onclick="menu('paket','Master', 'Paket','tampilconten');">
									<i class="menu-icon fa fa-caret-right"></i>
									Supplier / Agen
								</a>

								<b class="arrow"></b>
							</li>
								<li class="">
								<a href="javascript:;" onclick="menu('paket','Master', 'Paket','tampilconten');">
									<i class="menu-icon fa fa-caret-right"></i>
									Stok Gudang
								</a>

								<b class="arrow"></b>
							</li>

							<li class="">
								<a href="javascript:;" onclick="menu('paket','Master', 'Paket','tampilconten');">
									<i class="menu-icon fa fa-caret-right"></i>
									Master Paket 
								</a>

								<b class="arrow"></b>
							</li>




							<li class="">
								<a href="#" class="dropdown-toggle">
									<i class="menu-icon fa fa-caret-right"></i>

									Master Utility
									<b class="arrow fa fa-angle-down"></b>
								</a>

								<b class="arrow"></b>

								<ul class="submenu">
									<li class="">
										<a href="#">
											<i class="menu-icon fa fa-leaf green"></i>
											Item #1
										</a>

										<b class="arrow"></b>
									</li>

									<li class="">
										<a href="#" class="dropdown-toggle">
											<i class="menu-icon fa fa-pencil orange"></i>

											4th level
											<b class="arrow fa fa-angle-down"></b>
										</a>

										<b class="arrow"></b>

										<ul class="submenu">
											<li class="">
												<a href="#">
													<i class="menu-icon fa fa-plus purple"></i>
													Add Product
												</a>

												<b class="arrow"></b>
											</li>

											<li class="">
												<a href="#">
													<i class="menu-icon fa fa-eye pink"></i>
													View Products
												</a>

												<b class="arrow"></b>
											</li>
										</ul>
									</li>
								</ul>
							</li>
						</ul>
					</li>
						<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-desktop"></i>
							<span class="menu-text">
								Transaksi  
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="<? echo base_url();?>index.php/transaksi_masuk" >
									<i class="menu-icon fa fa-caret-right"></i>

									Transaksi Masuk
								</a>
								
							</li>
							<li class="">
								<a href="<? echo base_url();?>index.php/transaksi_keluar" >
									<i class="menu-icon fa fa-caret-right"></i>

									Transaksi Keluar
								</a>
								
							</li>

						</ul>

					    </li>

					    	<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon fa fa-desktop"></i>
							<span class="menu-text">
								Laporan  
							</span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="<? echo base_url();?>index.php/lap_transaksi_masuk" >
									<i class="menu-icon fa fa-caret-right"></i>

									Transaksi Masuk
								</a>
								
							</li>
							<li class="">
								<a href="<? echo base_url();?>index.php/lap_transaksi_keluar" >
									<i class="menu-icon fa fa-caret-right"></i>

									Transaksi Keluar
								</a>
								
							</li>

						</ul>

					    </li>