
								<!-- PAGE CONTENT BEGINS -->
								<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									Selamat Datang
									<strong class="green">
										Sistem Informasi Laundry 
										<small>(bima)</small>
									</strong>,
								</div>

								

								<!-- PAGE CONTENT ENDS -->