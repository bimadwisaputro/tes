
<!DOCTYPE html>
<html>

<head>

  <meta charset="UTF-8">

  <title>Twitter Aplication</title>

    <link rel="stylesheet" href="<? echo base_url(); ?>assets/css/style_profil.css" media="screen" type="text/css" />

    <link rel="stylesheet" href="<? echo base_url(); ?>assets/css/bootstrap.css" media="screen" type="text/css" />

  <script src='<? echo base_url(); ?>assets/js/bootstrap.js'></script>

  <script src='<? echo base_url(); ?>assets/js/jquery.js'></script>



  <script src='<? echo base_url(); ?>assets/js/jquery.min.js'></script>

  <script src="<? echo base_url(); ?>assets/index.js"></script>

    <script type="text/javascript">
    	$(document).ready(function(){
$(':input[type=file]').change( function(event) {
	var tmppath = URL.createObjectURL(event.target.files[0]);
	$(this).next("img").attr('src',tmppath);

	$("#gambar").val(tmppath);
});



	
  
					


});


    </script>

</head>

<div id="tampil">
<body>
<?
$info = $this->session->flashdata('info');
if(!empty($info))
{
	echo "
<div class='alert alert-success' role='alert'>
				<h4>$info</h4>
				</div>";

}
?>
 
<div id="status_input">

  <h1>Twitter Aplication</h1>
<form class='uploadformq' id='defaultForm' method='post' enctype='multipart/form-data' action='<? echo site_url();?>/profile/simpan'>
	<a href="<?echo site_url();?>/home">Home</a>
    <input type="hidden" value="<? echo $mail; ?>" name="emailx" id="emailx">
    <input type="hidden" value="<? echo $uname; ?>" id="namax">

    <input type="hidden" value="" id="gambar">

    <input type="hidden" value="<? echo $password; ?>" id="passwordx">
<table>
	<tr>
	<td>
    <ul class="nav ace-nav">
    <li >
    	

    	<input type="file" name="file" id="file" class="inputfile" />


		<? 
			
			foreach ($datablob->result() as $row) { ?>
			
								
					<? 

					if(!empty($row->foto)){
					echo'<img class="nav-user-photo" height="100px" width="100px" src="data:image/jpeg;base64,' . base64_encode($row->foto) . ' " >'; 
				}else{
					?>
					<img class="nav-user-photo" height="100px" width="100px" src="<? echo base_url();?>assets/img/user.gif" >

					<?
				}
					
			}
			?>

<label for="file" class="tombol" >Upload</label>
	</li>

	</ul>
  </td>

<td class="formnya">
<table  width="100%">
<tr>
<td><input type="text" id="nama" name="nama" value="<? echo $uname; ?>"></td>
</tr>
<tr>
<td><input type="text" id="email" name="email" value="<? echo $mail; ?>"></td>
</tr>
<tr>
<td><input type="password" id="password" name="password" value="<? echo $password; ?>"></td>
</tr>
<tr>
<td align="right"><input type="submit" id="simpan" value="Save" class="btn btn-primary"></td>
</tr>

</table>
</td>
</tr>
  </form>




</div>


</body>
</div>
</html>