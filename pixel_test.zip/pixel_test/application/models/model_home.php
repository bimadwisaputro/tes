<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_home extends CI_model 
{

	public function getblob($b)
	{
		
		$data = "select foto from m_user where email='$b' ";
		return $this->db->query($data);
	}

	public function getinsert($data)
	{
		
			$this->db->query("INSERT INTO tx_status (email,nama,tgl_status,isi_status) 
			values
			('$data[email]','$data[nama]',now(),'$data[status]') ");
		
	}




}