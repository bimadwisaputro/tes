<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_login extends CI_model 
{

	public function getlogin($u,$p)
	{
	//	$pwd = md5($p);
		$this->db->where('email',$u);
		$this->db->where('password',$p);

		$query = $this->db->get('m_user');
	//echo"<script>alert('$query');</script>";
			if($query->num_rows()>0)
			{

				foreach ($query->result() as $row) 
				{

				$sess =  array( 'email' 	=> $row->email ,
								'nama' 		=> $row->nama,
								'password' 		=> $row->password
				 			  );
			
				$this->session->set_userdata($sess);
				echo"OK";
			
				//redirect('home');
				

				}

			}else{
			echo"Maaf username atau password salah ";
			//$this->session->set_flashdata('info','');
				//redirect('login');

			}
	}
}