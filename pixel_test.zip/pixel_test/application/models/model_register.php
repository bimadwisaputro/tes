<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_register extends CI_model 
{


		public function getdata($key)
	{

		$this->db->where('email',$key);
		$hasil = $this->db->get('m_user');
		
		return $hasil;


	}


	

	public function getinsert($data)
	{
		$this->db->query("INSERT INTO m_user (email,nama,password) 
			values
			('$data[email]','$data[nama]','$data[pass]') ");
		
		
	}
	

}