<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_sec extends CI_model 
{

	public function getsec()
	{

		$username = $this->session->userdata('email');
		if(empty($username))
		{
			$this->session->sess_destroy();
			redirect('login');
		}

	}

}
