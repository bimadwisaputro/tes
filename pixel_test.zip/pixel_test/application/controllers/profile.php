<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile extends CI_Controller {

public function index()
	{

		$this->model_sec->getsec();

		$isi['uname'] = $this->session->userdata('nama');
		$isi['mail'] = $this->session->userdata('email');

		$isi['password'] = $this->session->userdata('password');
			$b =  $this->session->userdata('email');
		$this->load->model('model_home');
		$isi['datablob'] = $this->model_home->getblob($b);

	$this->load->view('tampil_profile',$isi);

	}

	public function simpan(){
	//AMBIL DARI FORM INPUT// 
    
    $file_name = $_FILES['file']['name']; 
    $tmp_name  = $_FILES['file']['tmp_name']; //nama local temp file di server
    $file_size = $_FILES['file']['size']; 
    $file_type = $_FILES['file']['type']; //tipe filenya (langsung detect MIMEnya)
		
		$data['email'] = $this->input->post('email');
		$data['password'] = $this->input->post('password');
		$data['nama'] = $this->input->post('nama');
		$key = $this->input->post('emailx');


	//OPERASI FILE//
    $fp = fopen($tmp_name, 'r'); // open file (read-only, binary)
    $file = fread($fp, $file_size) or die("Tidak dapat membaca source file"); // read file
    $file_content = mysql_real_escape_string($file) or die("Tidak dapat membaca source file"); // parse image ke string
    fclose($fp); 

    	$this->db->query("update  m_user set email='$data[email]',nama='$data[nama]',password='$data[password]',foto='$file_content' where email='$key'");
		//echo"<script>alert('upload Berhasil')</script>";
		$this->session->set_flashdata('info','Data Berhasil Di Simpan');
		
    	redirect('profile');

		
	}	

}

