<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Register extends CI_Controller {



	public function simpan(){

		$key = $this->input->post('email');
		$data['email'] = $this->input->post('email');
		$data['pass'] = $this->input->post('pass');
		$data['nama'] = $this->input->post('nama');

		
		
		$this->load->model('model_register');
		$query = $this->model_register->getdata($key);
		 $asu = $query->num_rows();
		// echo $asu;
		if($query->num_rows()>0)
		{
			echo"Maaf Data Sudah ada";

		}else{
			$nsert = $this->model_register->getinsert($data);
		//	echo $nsert;
				echo"OK";
			
			
		}
	}
	
}
