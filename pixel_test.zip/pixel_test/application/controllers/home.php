<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

public function index()
	{

		$this->model_sec->getsec();

		$isi['uname'] = $this->session->userdata('nama');
		$isi['mail'] = $this->session->userdata('email');

		$isi['data'] = $this->db->query("select a.*,b.foto from tx_status as a
			left join m_user as b on a.email=b.email
		 order by a.tgl_status desc");
	$this->load->view('tampilan_home',$isi);

	}	

public function logout()
	{
	$this->session->sess_destroy();
	redirect('login');
		
	}	


	public function simpan(){

//		$key = $this->input->post('email');
		$data['email'] = $this->input->post('email');
		$data['status'] = $this->input->post('status');
		$data['nama'] = $this->input->post('nama');

		
		
		$this->load->model('model_home');
		$query = $this->model_home->getinsert($data);
		
			
		//echo"OK";

		$isi['uname'] = $this->session->userdata('nama');
		$isi['mail'] = $this->session->userdata('email');	
		$isi['data'] = $this->db->query("select a.*,b.foto from tx_status as a
			left join m_user as b on a.email=b.email
		 order by a.tgl_status desc");
			$this->load->view('tampilan_home',$isi);

	}


}

